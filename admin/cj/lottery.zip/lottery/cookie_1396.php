<?php
$cookie['value']    =	'ccsalt=fc050eb3b8876078ca29b8c154d532d8';
$cookie['time']		=	1460644445;
